"""Check paired execution, produce policy-side commissioning diagnostics and hash the evidence."""
from pathlib import Path
import argparse, tempfile
import cv2
import numpy as np
from pilot import Cell, HERE, OUT, CAL, decode, sha, read, save, reference_geometry, policy_interface

def reference(path, row, cal, cam):
    def project(pixels,z,cam_name):
        c=cal['cameras'][cam_name];pts=np.asarray(pixels);origin=np.array(c['xyz_W_mm'])
        rays=np.column_stack(((pts[:,0]-239.5)/c['focal_px'],(179.5-pts[:,1])/c['focal_px'],-np.ones(len(pts))))@np.array(c['axes_W']).T
        return (origin+rays*((z-origin[2])/rays[:,2])[:,None])[:,:2]
    original=reference_geometry.xy
    try:
        reference_geometry.xy=project
        return reference_geometry.geometry(path,row,cam)
    finally:reference_geometry.xy=original

def check(case,model):
    root=OUT/case;out=root/model;cp=out/'lift.npz';cal=read(root/'calibration.json')
    first,top=[read(out/(b+'-action.json'))['action'] for b in ('first','overhead')]
    row=read(root/'public.json')
    row['eye_ref'],row['eye_valid']=reference(root/'initial-eye.png',row,cal,'eye')
    row['first']=first
    top_ref,valid=reference(root/'initial-top.png',row,cal,'top')
    gates={gate:policy_interface.choose_action(row,True,gate,top,top_ref,valid) for gate in ('old','new')}
    save(out/'gate-audit.json',dict(first_stage=row,top=top,top_ref=top_ref,top_valid=valid,measured=gates,
        skipped=policy_interface.choose_action(row,False,'new'),allocation='not ranked: two commissioning scenes, not a five-piece production batch'))
    cell=Cell(case)
    try:
        with tempfile.TemporaryDirectory(dir=out) as temp:
            repeat=Path(temp)
            for name in ('grip.json','lift.npz','prefix.npz'):(repeat/name).symlink_to((out/name).resolve())
            control=cell.run_branch(repeat,'first',first)
            recorded=read(out/'first/receipt.json')
            expected_trace=read(out/'first/trace.json');actual_trace=read(repeat/'first/trace.json')
            equal=expected_trace==actual_trace
            endpoint_equal=recorded['endpoint']==control['endpoint']
            check=dict(checkpoint_id=sha(cp),action=first,identical_contact_and_pose_trace=equal,
                       identical_released_endpoint=endpoint_equal,identical_outcome=recorded['success']==control['success'],
                       samples=len(expected_trace),both_success=bool(control['success'] and recorded['success']))
            save(out/'restore-check.json',check)
            if not (equal and endpoint_equal and check['identical_outcome']):raise RuntimeError(check)
    finally:cell.ren.close()
    stats={}
    for branch in ('first','overhead'):
        folder=out/branch;r=read(folder/'receipt.json')
        assert r['checkpoint_id']==sha(cp)
        cap=cv2.VideoCapture(str(folder/'continuous.mp4'))
        count=0
        while cap.read()[0]:count+=1
        cap.release()
        trace=read(folder/'trace.json')
        assert count==len(read(out/'grasp-trace.json'))+len(trace)
        stats[branch]=dict(frames=count,success=r['success'],failure_stage=r['failure_stage'])
        r['calibration_id']=CAL;r['calibration_sha256']=sha(root/'calibration.json')
        r['controller_sha256']=sha(HERE/'pilot.py')
        r['input_manifest_sha256']=sha(out/(branch+'-input.json'))
        r['action_reply_sha256']=sha(out/(branch+'-reply.json'))
        save(folder/'receipt.json',r)
    files={str(f.relative_to(out)):sha(f) for f in sorted(out.rglob('*')) if f.is_file() and f.name!='manifest.json'}
    save(out/'manifest.json',dict(checkpoint_id=sha(cp),branches=stats,files=files))
    print(case,model,stats,'restore matched',flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('case');ap.add_argument('model');args=ap.parse_args()
    check(args.case,args.model)
