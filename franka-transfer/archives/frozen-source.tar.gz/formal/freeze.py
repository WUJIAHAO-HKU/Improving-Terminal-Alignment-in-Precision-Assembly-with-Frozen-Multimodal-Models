"""Seal design before generating test conditions."""
from pathlib import Path
import json,hashlib,secrets,datetime
import design
root=Path(__file__).resolve().parent
lock=root/'freeze.json'
if lock.exists():raise SystemExit('already frozen')
paths=list((root.parent/'commissioning/vendor').rglob('*'))+[root.parent/'commissioning'/n for n in ('pilot.py','audit_pair.py')]+[root/n for n in ('design.py','inference.py','physics.py','simulation.py','freeze.py')]+[root.parent/'commissioning/runs/franka-pilot-v1/pilot-blade/calibration.json']
seed=secrets.randbits(63)
cfg=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),seed=seed,
    protocol='Franka four-task handoff v1.0. Pilot acceptance and immediate formal launch authorized by operator; fixed pilot calibration/controller and original gains.',
    models=['gpt-6.2-sol','gpt-6.1-terra'],effort='medium',task_counts=dict(twin=25,blade=25,dshaft=25,connector=25),
    batching='20 mixed blocks of five; same round-15 physical sampling ranges and deterministic task ordering; independent new seed',
    arms=['old x old','new x old','old x new','new x new'],quotas=[4,3],baseline='all 5 x new acceptance',
    scoring='all starts; failed grasp zero both branches; no infrastructure failure imputation; same two branch candidates for all comparisons',
    ni='separate by model; twenty batch-paired differences; 97.5% one-sided Student t lower bound strictly above -0.05 with nonzero variance; 4 before 3; 3 descriptive if 4 fails',
    evidence='all trajectories, checkpoints, final images and poses; continuous video for the already completed commissioning cases; formal run retains the frames and traces required in the ZIP',
    files={str(p.relative_to(root.parent)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths if p.is_file() and '__pycache__' not in p.parts})
with lock.open('x') as f:json.dump(cfg,f,indent=2)
rows=design.generate(seed)
for r in rows:
    r['port']=('near' if r['other_y']>0 else 'far') if r['task']=='connector' else ''
assert len(rows)==100 and len({r['id'] for r in rows})==100
assert all(sum(r['task']==t for r in rows)==25 for t in design.TASKS)
assert all(sum(r['batch']==b for r in rows)==5 for b in range(20))
with (root/'scenes.json').open('x') as f:json.dump(rows,f,indent=2)
print(lock,seed)
