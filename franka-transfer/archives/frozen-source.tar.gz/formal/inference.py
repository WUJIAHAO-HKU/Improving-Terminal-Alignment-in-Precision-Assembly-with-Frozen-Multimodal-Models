"""Call round-15 vision models on public formal images only. Run on the inference host."""
import argparse
import concurrent.futures
import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
import time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
RUN=ROOT/'records'
MODELS=('gpt-6.2-sol','gpt-6.1-terra')

def request(scene,model,mode):
    public=json.loads((scene/'public.json').read_text())
    dest=scene/model;dest.mkdir(exist_ok=True)
    reply=dest/(mode+'-reply.json')
    if reply.exists():return True
    name={'twin':'two-dowel cover','connector':'two-hole keyed connector','blade':'slotted blade collar','dshaft':'D-shaped sleeve with flat to local +X'}[public['task']]
    prompt=("You operate a Franka Panda robot with a parallel-jaw gripper. Reply JSON only. No tools. World X increases toward image right, Y away; yaw is counterclockwise from above. Images 480x360. Pixel coordinates (u,v) from top left. The gray movable component starts left of the dark receiving fixture with brass mating features. "
            f"The task is to insert the unmarked {name}. Recipe dimension {public['size']} mm, part outer width {public['width']} mm, clearance per side {public['gap']} mm. ")
    imgs=[scene/'initial-eye.png']
    if mode=='grip':
        prompt+='Command pick and lift; locate two points on its longitudinal centerline, symmetric about the MOVABLE component center, left then right, on the top face. Do not target the receiving fixture. Use visible long plate edges to judge yaw. Return {"op":"pick","points":[[u,v],[u,v]]}.'
    else:
        imgs.append(dest/'live-eye.png')
        prompt+='First image is the original oblique view and second is live after model-commanded grasp/lift. '
        if public['port']:
            prompt+=f"The order specifies the {public['port']} receiver: near means closer to the oblique camera (smaller world Y), far means further from it. Both are physically mateable; only the requested socket counts. "
        if mode=='overhead':
            imgs.append(scene/'initial-top.png')
            prompt+='Third image is the optional simultaneous overhead view of the ORIGINAL scene. Output pixel coordinates in that THIRD image. '
        else:
            prompt+='Output pixel coordinates in the FIRST image. '
        prompt+='Command motion to the receiving feature and insertion followed by release. Give two points along the long mating axis at the 14 mm high peg tops, symmetric around the desired wrist center. For twin or connector use both pin tops. For a slot use the ends of the blade centerline. For D-shaft use ends of an axis passing through its shaft center and pointing to the flat, NOT the truncated silhouette midpoint. Correct for grasp offset if visible. Return {"op":"assemble","points":[[u1,v1],[u2,v2]]}.'
    (dest/(mode+'-input.json')).write_text(json.dumps(dict(prompt=prompt,model=model,effort='medium',images=[dict(path=str(i.relative_to(scene)),sha256=hashlib.sha256(i.read_bytes()).hexdigest()) for i in imgs]),indent=2))
    # A re-acquisition after a documented outage has a new cycle and identical inputs.
    cycle=int(os.environ.get("FRANKA_RECOVERY_CYCLE","0"))
    for n in range(1,4):
        audit=dest/f'{mode}-cycle-{cycle}-attempt-{n}.json'
        if audit.exists():continue
        t=time.monotonic();raw='';err=None
        with tempfile.TemporaryDirectory() as td:
            w=Path(td);cmd=['codex','exec','--ephemeral','--ignore-user-config','--skip-git-repo-check','-s','read-only','--color','never','-c','model_reasoning_effort="medium"','-m',model,'-o',str(w/'answer')]
            for j,im in enumerate(imgs):
                f=w/f'view{j}.png';shutil.copyfile(im,f);cmd+=['-i',str(f)]
            try:
                p=subprocess.run(cmd+['--','-'],input=prompt,text=True,capture_output=True,cwd=w,timeout=230)
                if p.returncode:
                    failures=[x[:350] for x in p.stderr.splitlines() if re.search('error|unsupported|timed out|unavailable',x,re.I)]
                    raise RuntimeError('model call failed: '+' '.join(failures[-2:]))
                if re.search(r'^exec\s*$',p.stderr,re.M):raise ValueError('tool use')
                raw=(w/'answer').read_text()
                q=json.loads(re.search(r'\{[^{}]+\}',raw).group())
                pts=q['points']; assert q['op']==('pick' if mode=='grip' else 'assemble') and len(pts)==2 and all(len(a)==2 and 0<=a[0]<480 and 0<=a[1]<360 for a in pts)
            except Exception as e:err=str(e)
        audit.write_text(json.dumps(dict(model=model,mode=mode,seconds=time.monotonic()-t,attempt=n,raw=raw,error=err),indent=2))
        if err is None:
            reply.write_text(json.dumps(q,indent=2));print(scene.name,model,mode,'reply recorded',flush=True);return True
        print(scene.name,model,mode,'attempt',n,'failed',err[:120],flush=True)
    return False

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('modes',nargs='+',choices=['grip','first','overhead']);args=ap.parse_args()
    jobs=[(s,m,k) for s in sorted(RUN.glob('F[0-9][0-9][0-9]')) for m in MODELS for k in args.modes]
    with concurrent.futures.ThreadPoolExecutor(max_workers=12) as pool:
        ok=list(pool.map(lambda a:request(*a),jobs))
    raise SystemExit(0 if all(ok) else 1)
