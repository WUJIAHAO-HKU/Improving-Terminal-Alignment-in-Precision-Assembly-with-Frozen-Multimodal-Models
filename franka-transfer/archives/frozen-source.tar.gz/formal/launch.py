"""Run the frozen pair collection on the configured simulator host and inference locally; resume existing replies."""
from pathlib import Path
import os
import subprocess
import sys
import time
ROOT=Path(__file__).resolve().parent
SSH=['ssh','-o','BatchMode=yes']
HOST=os.environ.get('FRANKA_SSH_HOST','assembly-sim')
REMOTE=os.environ.get('FRANKA_REMOTE_DIR','assembly-jobs/franka')
PERSIST=os.environ.get('FRANKA_ARCHIVE_DIR','assembly-jobs/franka-archive')
PY=os.environ.get('FRANKA_PYTHON','python3')
PREFIX=f'cd {REMOTE} && export MUJOCO_GL=egl PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 && '
def run(args):
    subprocess.run(args,check=True)
def remote(cmd):
    run(SSH+[HOST,PREFIX+cmd])
def sync(pull):
    loc=str(ROOT/'records')+'/'
    rem=HOST+':'+REMOTE+'/formal/records/'
    src,dst=(rem,loc) if pull else (loc,rem)
    flags=[] if pull else ['--include=*/','--include=*-input.json','--include=*-reply.json','--include=*-attempt-*.json','--exclude=*']
    run(['rsync','-a','-e',' '.join(SSH),*flags,src,dst])
def phase(name,fn):
    marker=ROOT/(name+'.ok')
    if marker.exists():return
    print(time.strftime('%FT%T'),name,flush=True)
    fn();marker.touch()
def infer(mode):
    run([sys.executable,str(ROOT/'inference.py'),mode])
    sync(False)
def physics(mode):
    remote(f'{PY} formal/simulation.py {mode}')
    sync(True)
def archive():
    remote(f'{PY} formal/pack.py {PERSIST}')
    dest=ROOT/'archives';dest.mkdir(exist_ok=True)
    run(['rsync','-a','-e',' '.join(SSH),'--include=*.tar.gz','--include=*.sha256','--exclude=*',HOST+':'+PERSIST+'/',str(dest)+'/'])
if __name__=='__main__':
    for mode in ['initial','grip','first','rank','overhead','branches','archive']:
        if mode=='grip':
            phase('infer-grip',lambda:infer('grip'))
            phase('sim-grip',lambda:physics('grip'))
        elif mode in ('first','overhead'):phase('infer-'+mode,lambda m=mode:infer(m))
        elif mode=='archive':phase('archive',archive)
        else:phase('sim-'+mode,lambda m=mode:physics(m))
