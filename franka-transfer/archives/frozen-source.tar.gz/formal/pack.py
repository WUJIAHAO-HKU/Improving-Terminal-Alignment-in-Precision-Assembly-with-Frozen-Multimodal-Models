"""Checkpoint the complete raw records in one persistent, verified archive per batch."""
from pathlib import Path
import hashlib,json,sys,tarfile
root=Path(__file__).resolve().parent
dest=Path(sys.argv[1])
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rows=json.loads((root/'scenes.json').read_text());sums=[]
for b in range(20):
    name=f'batch-{b:02}.tar.gz';p=dest/name;tmp=dest/(name+'.part')
    with tarfile.open(tmp,'w:gz',compresslevel=3) as z:
        for r in [v for v in rows if v['batch']==b]:
            for m in ('gpt-6.2-sol','gpt-6.1-terra'):
                assert (root/'records'/r['id']/m/'branches.complete').exists()
            z.add(root/'records'/r['id'],arcname='records/'+r['id'])
        for model in ('gpt-6.2-sol','gpt-6.1-terra'):
            f=Path('records/rankings')/model/f'{b:02}.json';z.add(root/f,arcname=str(f))
    tmp.replace(p);sums.append(f'{digest(p)}  {name}')
(dest/'batches.sha256').write_text('\n'.join(sums)+'\n')
