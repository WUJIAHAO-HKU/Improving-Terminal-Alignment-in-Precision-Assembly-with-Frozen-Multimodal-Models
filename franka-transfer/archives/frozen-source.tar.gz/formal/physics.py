"""Formal Franka physics adapter derived from the verified commissioning controller."""
import argparse
import hashlib
import json
import math
import sys
from pathlib import Path
from xml.etree import ElementTree as ET

import cv2
import mujoco as mj
import numpy as np
from PIL import Image

HERE = Path(__file__).resolve().parents[1] / "commissioning"
for source in ("franka", "round15", "handoff"):
    sys.path.insert(0, str(HERE / "vendor" / source))
import profiles
import policy_interface
import reference_geometry
import station
from robot import Bench

BASE = np.array([0.50, -0.04, 0.0])
SPEC = mj.mjtState.mjSTATE_INTEGRATION
DT = .002
SAMPLE = 20  # steps, 40 ms
CAL = "franka-pilot-v1"
RUN_ID = "franka-four-formal-v1"
OUT = Path(__file__).resolve().parent / "records"

def save(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False, default=lambda x:x.tolist()))

def read(path):
    return json.loads(path.read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def norm(x):
    return x / np.linalg.norm(x)

def make_model(r):
    root = ET.parse(HERE/'vendor/franka/template.xml').getroot()
    root.find('option').set('timestep',str(DT))
    for body in root.findall('.//worldbody//body'):
        body.set('gravcomp','1')
    grip=root.find(".//general[@name='actuator8']")
    grip.set('gainprm','.25 0 0'); grip.set('biasprm','0 -1593.75 -15')
    w=root.find('worldbody')
    station.elem(w,'light',pos='.52 -.40 .95',dir='0 .3 -1')
    station.elem(w,'light',pos='.30 .45 .80',dir='0 -.4 -1')
    station.elem(w,'geom',type='plane',size='1 1 .02',rgba='.32 .34 .36 1',friction='1.3 .01 .0003')
    hand=root.find(".//body[@name='hand']")
    station.elem(hand,'site',name='tcp',pos='0 0 .104',size='.001',rgba='0 0 0 0')
    for name in ('left_finger','right_finger'):
        body=root.find(f".//body[@name='{name}']")
        for g in list(body.findall('geom')):
            if g.get('mesh'):
                g.set('contype','0'); g.set('conaffinity','0')
            else:
                body.remove(g)
        station.elem(body,'geom',name=name+'_pad',type='box',pos='0 .002 .043',size='.009 .002 .004',mass='.007',rgba='.1 .1 .1 1',friction='2 .02 .001',solref='.004 1',solimp='.97 .995 .0001',priority=1,condim=4)
    # Generate only original fixtures; preserve all Panda meshes.
    sub=ET.fromstring('<mujoco><asset/><worldbody><body name="fixture"/><body name="cover"/></worldbody></mujoco>')
    profiles.attach(sub,r)
    root.find('asset').extend(list(sub.find('asset')))
    work=station.elem(w,'body',name='worktable_W',pos=BASE)
    # A free body is a direct child of world; place each fixture element in the W frame.
    for node in list(sub.find('worldbody')):
        name=node.get('name')
        if name in ('fixture','cover'):
            if name=='fixture':
                xyz=[r['tx'],r['ty'],0]; yaw=r['ta']
            else:
                xyz=[r['sx'],r['sy'],3.04]; yaw=r['sa']
                station.elem(node,'freejoint',name='loosepart')
                station.elem(node,'inertial',pos='0 0 0',mass='.042',diaginertia='.0000022 .000010 .000011')
            node.set('pos',station.fmt(BASE+np.array(xyz)/1000))
            node.set('euler',station.fmt([0,0,np.deg2rad(yaw)]))
            w.append(node)
        else:
            work.append(node)
    for name,cam,aim,fov in [('eye',(8,-228,250),(0,0,6),37),('top',(0,0,318),(0,0,0),36),('video',(225,-360,240),(-15,0,65),43)]:
        c=np.array(cam); back=norm(c-np.array(aim))
        cross=np.cross([0,0,1],back)
        right=norm(cross) if np.linalg.norm(cross)>0 else np.array([1.,0,0])
        station.elem(work,'camera',name=name,pos=c/1000,xyaxes=[*right,*np.cross(back,right)],fovy=fov)
    xml=ET.tostring(root,encoding='unicode')
    assets={p.name:p.read_bytes() for p in (HERE/'vendor/franka/assets').iterdir()}
    m=mj.MjModel.from_xml_string(xml,assets=assets)
    return m,xml

class Cell:
    def __init__(self,r):
        self.case=r["id"]; self.r=r; self.m,self.xml=make_model(self.r)
        self.d=mj.MjData(self.m); self.tmp=mj.MjData(self.m)
        self.d.qpos[:9]=[0,-.35,0,-2.15,0,1.82,.78,.04,.04]
        self.d.ctrl[:]=[*self.d.qpos[:7],255]
        mj.mj_forward(self.m,self.d)
        self.ren=mj.Renderer(self.m,height=360,width=480)
        self.names=[self.m.geom(i).name or '' for i in range(self.m.ngeom)]
        self.part=self.m.body('cover').id; self.site=self.m.site('tcp').id
        self.tick=0; self.trace=[]; self.frames=[]; self.stage='initial'
        self.folder=OUT/self.case
    def snap(self,cam):
        self.ren.update_scene(self.d,camera=cam)
        return self.ren.render().copy()
    def observe(self):
        hits=set()
        for c in self.d.contact:
            a,b=self.names[c.geom1],self.names[c.geom2]
            if a.startswith('cover_'):hits.add(b)
            if b.startswith('cover_'):hits.add(a)
        R=self.d.xmat[self.part].reshape(3,3)
        return dict(time_s=float(self.d.time),stage=self.stage,part_mm=((self.d.xpos[self.part]-BASE)*1000).tolist(),part_quat=self.d.xquat[self.part].tolist(),tcp_mm=((self.d.site_xpos[self.site]-BASE)*1000).tolist(),left='left_finger_pad' in hits,right='right_finger_pad' in hits,contacts=sorted(hits),tilt_deg=float(np.degrees(np.arccos(np.clip(R[2,2],-1,1)))))
    def step(self,n):
        for _ in range(n):
            mj.mj_step(self.m,self.d);self.tick+=1
            if self.tick%SAMPLE==0:
                self.trace.append(self.observe())
                # The formal protocol retains per-branch trajectories and terminal images.
    def move(self,action,z,grip,n=360):
        point=BASE+np.array([action['x'],action['y'],z])/1000
        theta=np.deg2rad(action['yaw']); c,s=np.cos(theta),np.sin(theta)
        target=np.array([[c,s,0],[s,-c,0],[0,0,-1]])
        m,d=self.m,self.tmp;d.qpos[:]=self.d.qpos
        lim=m.jnt_range[:7]; jp=np.zeros((3,m.nv));jr=jp.copy()
        for _ in range(110):
            mj.mj_forward(m,d);rot=d.site_xmat[self.site].reshape(3,3)
            ang=sum(np.cross(rot[:,j],target[:,j]) for j in range(3))*.5
            err=np.r_[point-d.site_xpos[self.site],ang]
            if np.linalg.norm(err[:3])<.00008 and np.linalg.norm(ang)<.002:break
            mj.mj_jacSite(m,d,jp,jr,self.site)
            J=np.vstack((jp[:,:7],jr[:,:7]))
            dq=J.T@np.linalg.solve(J@J.T+np.eye(6)*.00012,err)
            d.qpos[:7]=np.clip(d.qpos[:7]+np.clip(dq,-.14,.14),lim[:,0]+.001,lim[:,1]-.001)
        dest=d.qpos[:7].copy();start=self.d.ctrl[:7].copy();self.d.ctrl[7]=grip
        for k in range(n):
            u=(k+1)/n;self.d.ctrl[:7]=start+(dest-start)*u*u*(3-2*u);self.step(1)
        self.step(120)
    def state(self):
        a=np.empty(mj.mj_stateSize(self.m,SPEC));mj.mj_getState(self.m,self.d,a,SPEC);return a
    def checkpoint(self,path):
        # Controller target is included in INTEGRATION. IK scratch is reset from qpos per move.
        # This pilot is deterministic with fixed scene configurations and no stochastic controller.
        np.savez(path,state=self.state(),tick=self.tick,ik_qpos=self.tmp.qpos,controls=self.d.ctrl,sim_time=self.d.time)
        return sha(path)
    def restore(self,path):
        st=np.load(path);mj.mj_setState(self.m,self.d,st['state'],SPEC)
        self.tmp.qpos[:]=st['ik_qpos'];self.tick=int(st['tick'])
        mj.mj_forward(self.m,self.d)
        assert np.array_equal(self.d.ctrl,st['controls']) and self.d.time==st['sim_time']
        self.trace=[];self.frames=[]
    def calib(self):
        cams={}
        for name in ('eye','top'):
            i=self.m.camera(name).id
            cams[name]=dict(xyz_W_mm=((self.d.cam_xpos[i]-BASE)*1000).tolist(),axes_W=self.d.cam_xmat[i].reshape(3,3).tolist(),focal_px=float(180/np.tan(np.deg2rad(self.m.cam_fovy[i]/2))))
        return dict(id=CAL,resolution=[480,360],principal_point=[239.5,179.5],W_in_base_m=BASE.tolist(),W_axes_in_base=np.eye(3).tolist(),tcp_in_hand_m=self.m.site_pos[self.site].tolist(),cameras=cams)
    def initial(self):
        self.folder.mkdir(parents=True,exist_ok=True);self.stage='park'
        self.move(dict(x=-110,y=96,yaw=0),150,255)
        self.frames=[];self.trace=[]
        for cam in ('eye','top'):
            Image.fromarray(self.snap(cam)).save(self.folder/f'initial-{cam}.png')
        (self.folder/'model.xml').write_text(self.xml)
        save(self.folder/'calibration.json',self.calib())
        save(self.folder/'public.json',{k:self.r[k] for k in ('task','size','gap','radius','width')}|dict(scene_id=self.case,batch_id=self.r['batch'],port=self.r.get('port',''),calibration_id=CAL))
        self.checkpoint(self.folder/'initial.npz')
    def grasp(self,out,pick):
        self.restore(self.folder/'initial.npz');self.stage='pick'
        self.move(pick,52,255);self.move(pick,3.5,255)
        self.stage='close'; self.d.ctrl[7]=self.closeval; self.step(320)
        self.stage='lift';self.move(pick,50,self.closeval)
        end=self.observe();ok=end['part_mm'][2]>25 and end['left'] and end['right']
        out.mkdir(parents=True,exist_ok=True)
        cp=self.checkpoint(out/'lift.npz')
        save(out/'grip.json',dict(checkpoint_id=cp,lifted=ok,end=end))
        save(out/'grasp-trace.json',self.trace)
        Image.fromarray(self.snap('eye')).save(out/'live-eye.png')
    @property
    def closeval(self):
        return max(0,(self.r['width']/2000-.004)/.04*255)
    def run_branch(self,out,branch,a):
        g=read(out/'grip.json');cp=out/'lift.npz';assert sha(cp)==g['checkpoint_id']
        self.restore(cp);path=out/branch;path.mkdir(parents=True,exist_ok=True)
        if g['lifted']:
            self.stage='carry';self.move(a,50,self.closeval,420)
            self.stage='insert';self.move(a,7.3,self.closeval,420)
            self.stage='release';self.d.ctrl[7]=min(255,(self.r['width']/2000+.008)/.04*255);self.step(200)
            self.stage='retract';self.move(a,75,self.d.ctrl[7],320);self.stage='settle';self.step(200)
        end=self.observe();R=self.d.xmat[self.part].reshape(3,3)
        margin=min(profiles.score(self.r,np.array(end['part_mm']),R))
        carry=sum(t['left'] and t['right'] for t in self.trace if t['stage']=='carry')
        drift=float(np.linalg.norm(np.array(self.trace[-1]['part_mm'])-self.trace[-4]['part_mm'])) if len(self.trace)>=4 else None
        stage=('grasp' if not g['lifted'] else 'carry' if carry<8 else 'endpoint' if end['right'] or end['left'] or margin<-.15 or not 6.6<end['part_mm'][2]<7.5 or end['tilt_deg']>=3 or drift>=.35 else 'seated')
        receipt=dict(run_id=RUN_ID,calibration_id=CAL,model=out.name,batch_id=self.r['batch'],scene_id=self.case,checkpoint_id=g['checkpoint_id'],branch=branch,action=a,lifted=g['lifted'],carry_bilateral_samples=carry,margin_mm=margin,drift_mm=drift,endpoint=end,success=stage=='seated',failure_stage=None if stage=='seated' else stage)
        save(path/'receipt.json',receipt);save(path/'trace.json',self.trace)
        self.checkpoint(path/'final.npz')
        for cam in ('eye','top'):Image.fromarray(self.snap(cam)).save(path/f'final-{cam}.png')
        return receipt

def decode(cal,points,cam,z):
    p=np.array(points,dtype=float)
    if p.shape!=(2,2) or not np.isfinite(p).all() or (p<0).any() or (p>=[480,360]).any():raise ValueError('invalid points')
    c=cal['cameras'][cam];R=np.array(c['axes_W']);origin=np.array(c['xyz_W_mm'])
    rays=np.column_stack(((p[:,0]-239.5)/c['focal_px'],(179.5-p[:,1])/c['focal_px'],-np.ones(2)))@R.T
    w=origin+rays*((z-origin[2])/rays[:,2])[:,None];dx,dy=w[1,:2]-w[0,:2]
    a=dict(x=w[:,0].mean(),y=w[:,1].mean(),yaw=(np.degrees(np.arctan2(dy,dx))+90)%180-90)
    return dict(unclipped=a,action=reference_geometry.pose(a['x'],a['y'],a['yaw']))

