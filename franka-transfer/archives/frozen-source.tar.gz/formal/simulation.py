"""Evaluator host. Rank on first-stage records before allowing overhead candidates."""
import argparse
import hashlib
import json
import multiprocessing as mp
from pathlib import Path
import sys
import numpy as np
from PIL import Image
import physics as ph
from physics import Cell, OUT, HERE, save, read, sha, decode
sys.path.insert(0,str(HERE))
from audit_pair import reference
from policy_interface import rank_batch, choose_action

MODELS=('gpt-6.2-sol','gpt-6.1-terra')
BASE=Path(__file__).resolve().parent

def get_action(scene,model,branch):
    folder=scene/model
    reply=read(folder/f'{branch}-reply.json')
    assert reply['op']==('pick' if branch=='grip' else 'assemble')
    act=decode(read(scene/'calibration.json'), reply['points'], 'top' if branch=='overhead' else 'eye', 6 if branch=='grip' else 14)
    save(folder/f'{branch}-action.json',act)
    return act['action']

def simulate(args):
    row,model,stage=args
    folder=OUT/row['id'];out=folder/model if model else folder
    done=out/(stage+'.complete')
    if done.exists():return
    cell=Cell(row)
    try:
        if stage=='initial':
            cell.initial()
        elif stage=='grip':
            cell.grasp(out,get_action(folder,model,'grip'))
        elif stage=='branches':
            public=read(folder/'public.json');cal=read(folder/'calibration.json')
            first=read(out/'first-stage.json')
            top=get_action(folder,model,'overhead')
            ref,ok=reference(folder/'initial-top.png',public,cal,'top')
            decisions={gate:choose_action(first,True,gate,top,ref,ok) for gate in ('old','new')}
            save(out/'gates.json',dict(top=top,top_ref=ref,top_valid=ok,gates=decisions))
            for branch,a in [('first',first['first']),('overhead',top)]:
                receipt=cell.run_branch(out,branch,a)
                receipt.update(controller_sha256=sha(BASE/'physics.py'),calibration_sha256=sha(folder/'calibration.json'),
                               input_manifest_sha256=sha(out/f'{branch}-input.json'),reply_sha256=sha(out/f'{branch}-reply.json'))
                save(out/branch/'receipt.json',receipt)
        else:raise ValueError(stage)
        done.touch()
    finally:cell.ren.close()

def rank(rows):
    for model in MODELS:
        for b in range(20):
            first=[]
            for row in [r for r in rows if r['batch']==b]:
                d=OUT/row['id']; public=read(d/'public.json')
                public['eye_ref'],public['eye_valid']=reference(d/'initial-eye.png',public,read(d/'calibration.json'),'eye')
                public['first']=get_action(d,model,'first')
                save(d/model/'first-stage.json',public);first.append(public)
            assert len(first)==5
            result={f'{a}-{n}':rank_batch(model,first,a,n) for a in ('old','new') for n in (3,4,5)}
            save(OUT/'rankings'/model/f'{b:02}.json',result)

def preflight():
    for task,offset in [('twin',0),('connector',39),('connector',-39)]:
        row=dict(ph.read(HERE/'runs'/'franka-pilot-v1'/'pilot-blade'/'public.json'))
        row.update(task=task,id='debug-'+task+str(offset),batch=-1,size=30.,sx=-45.,sy=3.,sa=6.,tx=40.,ty=-19. if offset>0 else 20.,ta=5.,other_y=offset,occ_x=-36.,occ_w=6.,port=('near' if offset>0 else 'far') if offset else '')
        c=Cell(row)
        try:
            c.initial()
            angle=np.deg2rad(row['ta']);co,si=np.cos(angle),np.sin(angle)
            rot=np.array([[co,-si,0],[si,co,0],[0,0,1.]])
            good=np.array([row['tx'],row['ty'],7.])
            assert min(ph.profiles.score(row,good,rot))>0
            if offset:
                wrong=good+rot@np.array([0,offset,0])
                assert min(ph.profiles.score(row,wrong,rot))<-.15
            print(task,offset,'render and target containment check passed',flush=True)
        finally:c.ren.close()

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('stage',choices=['initial','grip','rank','branches','preflight']);ap.add_argument('--workers',type=int,default=4);args=ap.parse_args()
    if args.stage=='preflight':preflight()
    else:
        rows=read(BASE/'scenes.json')
        if args.stage=='rank':rank(rows)
        else:
            jobs=[(r,m,args.stage) for r in rows for m in ([''] if args.stage=='initial' else MODELS)]
            with mp.get_context('spawn').Pool(args.workers,maxtasksperchild=15) as pool:
                for _ in pool.imap_unordered(simulate,jobs,chunksize=1):pass
